// Import Three.js from CDN
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';

// Import game systems
import { GameLoop } from './core/gameLoop.js';
import { InputManager } from './utils/input.js';
import { UIManager } from './utils/ui.js';
import { Warrior } from './player/Warrior.js';
import { Assassin } from './player/Assassin.js';
import { Wizard } from './player/Wizard.js';
import { Warlock } from './player/Warlock.js';
import { Level } from './world/Level.js';
import { Environment } from './world/Environment.js';
import { CameraFollow } from './camera/CameraFollow.js';
import { Goomba } from './entities/Goomba.js';

// Game state
let gameStarted = false;
let scene, camera, renderer, input, level, environment, player, uiManager, cameraFollow, gameLoop;

// Hero selection
let selectedHeroClass = null;

// Initialize scene (before game starts)
function initScene() {
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x5c94fc);

    const aspect = window.innerWidth / window.innerHeight;
    const viewSize = 10;
    camera = new THREE.OrthographicCamera(
        -viewSize * aspect,
        viewSize * aspect,
        viewSize,
        -viewSize,
        0.1,
        1000
    );
    camera.position.set(0, 0, 10);
    camera.lookAt(0, 0, 0);

    renderer = new THREE.WebGLRenderer({
        canvas: document.getElementById('game-canvas'),
        antialias: true
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(window.devicePixelRatio);

    // Handle window resize
    window.addEventListener('resize', () => {
        const aspect = window.innerWidth / window.innerHeight;
        camera.left = -viewSize * aspect;
        camera.right = viewSize * aspect;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    });
}

// Start game with selected hero
function startGame(HeroClass) {
    selectedHeroClass = HeroClass;

    // Hide menu
    document.getElementById('hero-menu').style.display = 'none';
    document.getElementById('ability-ui').style.display = 'flex';

    // Initialize input manager
    input = new InputManager();

    // Create environment (background, clouds, particles)
    environment = new Environment(scene);
    environment.createBackground();

    // Create level with platforms
    level = new Level(scene);
    level.createTestLevel();

    // Add enemies to level
    const goomba1 = new Goomba(scene, 8, 0);
    level.addEnemy(goomba1);

    const goomba2 = new Goomba(scene, -7, 0);
    level.addEnemy(goomba2);

    const goomba3 = new Goomba(scene, 12, 3);
    level.addEnemy(goomba3);

    const goomba4 = new Goomba(scene, -12, 0);
    level.addEnemy(goomba4);

    const goomba5 = new Goomba(scene, 15, 0);
    level.addEnemy(goomba5);

    // Create selected hero
    player = new HeroClass(scene, 0, 0);
    player.enemies = level.enemies;
    player.level = level; // Pass level reference for platform detection

    // Setup UI manager
    uiManager = new UIManager(player);

    // Setup camera follow
    cameraFollow = new CameraFollow(camera, player);
    cameraFollow.setSmoothing(0.1);

    // Game Loop
    gameLoop = new GameLoop(
        (deltaTime) => {
            player.update(deltaTime, input);
            level.updateEnemies(deltaTime);
            level.checkCollisions(player);
            player.checkEnemyCollisions(level.enemies);
            cameraFollow.update();
            uiManager.update();

            // Update environment animations
            environment.update(deltaTime);
        },
        () => {
            renderer.render(scene, camera);
        }
    );

    gameLoop.start();
    gameStarted = true;

    // Log hero info
    const heroNames = {
        [Warrior.name]: '⚔️ WARRIOR',
        [Assassin.name]: '🗡️ ASSASSIN',
        [Wizard.name]: '🔮 WIZARD',
        [Warlock.name]: '💀 WARLOCK'
    };

    console.log(`${heroNames[HeroClass.name]} SELECTED!`);
    console.log('Move: Arrow Keys/A/D | Jump: W/Space (double jump!)');
    console.log('Abilities: Q/Left Click = A1 | Right Click = A2 | E = A3 | R = Ultimate');
}

// Reset game (return to menu)
function resetGame() {
    if (gameLoop) {
        gameLoop.stop();
    }

    // Clear scene
    if (scene && player) {
        scene.remove(player.mesh);
        level.platforms.forEach(p => scene.remove(p.mesh));
        level.enemies.forEach(e => scene.remove(e.mesh));
    }

    // Show menu again
    document.getElementById('hero-menu').style.display = 'flex';
    document.getElementById('ability-ui').style.display = 'none';

    gameStarted = false;
}

// Initialize scene on load
window.addEventListener('load', () => {
    initScene();

    // Setup hero selection buttons
    document.getElementById('select-warrior').addEventListener('click', () => {
        startGame(Warrior);
    });

    document.getElementById('select-assassin').addEventListener('click', () => {
        startGame(Assassin);
    });

    document.getElementById('select-wizard').addEventListener('click', () => {
        startGame(Wizard);
    });

    document.getElementById('select-warlock').addEventListener('click', () => {
        startGame(Warlock);
    });

    // Setup reset button
    document.getElementById('reset-button').addEventListener('click', () => {
        resetGame();
    });

    // Render empty scene while in menu
    function menuRender() {
        if (!gameStarted) {
            renderer.render(scene, camera);
            requestAnimationFrame(menuRender);
        }
    }
    menuRender();
});
