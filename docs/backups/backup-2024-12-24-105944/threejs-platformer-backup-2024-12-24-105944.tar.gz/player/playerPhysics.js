import { GRAVITY, JUMP_VELOCITY } from '../core/constants.js';

/**
 * Apply gravity to player (collision handled by Level)
 * @param {Player} player - The player instance
 * @param {number} deltaTime - Time since last frame in seconds
 */
export function applyGravity(player, deltaTime) {
    // Apply gravity to vertical velocity
    player.velocity.y += GRAVITY * deltaTime;

    // Apply velocity to position
    player.position.y += player.velocity.y * deltaTime;

    // Assume not grounded (Level will set to true if on platform)
    player.isGrounded = false;
}

/**
 * Handle jump input for player (with double jump)
 * @param {Player} player - The player instance
 * @param {InputManager} input - The input manager
 */
export function handleJump(player, input) {
    const jumpPressed = input.isJumpPressed();

    // Reset jumps when grounded
    if (player.isGrounded) {
        player.jumpsRemaining = 2;
    }

    // Handle jump with key press detection to prevent spam
    if (jumpPressed && !player.jumpKeyWasPressed && player.jumpsRemaining > 0) {
        player.velocity.y = JUMP_VELOCITY;
        player.jumpsRemaining--;
        player.isGrounded = false;

        // Log which jump this is
        if (player.jumpsRemaining === 1) {
            console.log('First jump!');
        } else if (player.jumpsRemaining === 0) {
            console.log('Double jump!');
        }
    }

    // Track key state for next frame
    player.jumpKeyWasPressed = jumpPressed;
}
