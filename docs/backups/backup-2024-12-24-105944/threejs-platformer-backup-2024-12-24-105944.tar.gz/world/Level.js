import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';
import { checkAABBCollision, resolveCollisionY, resolveCollisionX } from '../utils/collision.js';

/**
 * Level - Manages platforms and level geometry
 * @class Level
 */
export class Level {
    constructor(scene) {
        this.scene = scene;
        this.platforms = [];
        this.enemies = [];
    }

    /**
     * Add a platform to the level
     * @param {number} x - Center X position
     * @param {number} y - Center Y position
     * @param {number} width - Platform width
     * @param {number} height - Platform height
     * @param {string} type - Platform type ('ground', 'grass', 'stone')
     * @returns {Object} Platform object
     */
    addPlatform(x, y, width, height, type = 'grass') {
        const platformGroup = new THREE.Group();

        // Main platform body
        const bodyGeometry = new THREE.BoxGeometry(width, height, 0.8);
        let bodyColor, topColor, sideColor;

        switch(type) {
            case 'ground':
                bodyColor = 0x8B4513;  // Brown dirt
                topColor = 0x228B22;   // Forest green grass
                sideColor = 0x654321;  // Dark brown
                break;
            case 'stone':
                bodyColor = 0x808080;  // Gray stone
                topColor = 0x696969;   // Darker gray
                sideColor = 0x505050;  // Very dark gray
                break;
            case 'grass':
            default:
                bodyColor = 0x8B4513;  // Brown
                topColor = 0x32CD32;   // Lime green
                sideColor = 0x654321;  // Dark brown
        }

        const bodyMaterial = new THREE.MeshBasicMaterial({ color: bodyColor });
        const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
        platformGroup.add(body);

        // Top layer (grass/stone surface)
        const topGeometry = new THREE.BoxGeometry(width, height * 0.15, 0.85);
        const topMaterial = new THREE.MeshBasicMaterial({ color: topColor });
        const top = new THREE.Mesh(topGeometry, topMaterial);
        top.position.y = height * 0.425;
        platformGroup.add(top);

        // Side highlights for depth
        const sideGeometry = new THREE.BoxGeometry(width * 0.98, height * 0.1, 0.75);
        const sideMaterial = new THREE.MeshBasicMaterial({ color: sideColor });
        const side = new THREE.Mesh(sideGeometry, sideMaterial);
        side.position.y = -height * 0.4;
        platformGroup.add(side);

        // Add detail patterns for grass platforms
        if (type === 'grass' || type === 'ground') {
            // Add grass tufts on top
            const numTufts = Math.floor(width * 2);
            for (let i = 0; i < numTufts; i++) {
                const tuftGeometry = new THREE.BoxGeometry(0.08, 0.15, 0.05);
                const tuftMaterial = new THREE.MeshBasicMaterial({
                    color: 0x228B22,
                    transparent: true,
                    opacity: 0.7
                });
                const tuft = new THREE.Mesh(tuftGeometry, tuftMaterial);
                tuft.position.set(
                    -width/2 + (i * width/numTufts) + Math.random() * 0.2,
                    height * 0.5 + 0.1,
                    Math.random() * 0.2 - 0.1
                );
                platformGroup.add(tuft);
            }
        }

        // Add texture detail lines for stone platforms
        if (type === 'stone') {
            const numLines = Math.floor(width);
            for (let i = 0; i < numLines; i++) {
                const lineGeometry = new THREE.BoxGeometry(width * 0.9, 0.03, 0.82);
                const lineMaterial = new THREE.MeshBasicMaterial({
                    color: 0x505050,
                    transparent: true,
                    opacity: 0.3
                });
                const line = new THREE.Mesh(lineGeometry, lineMaterial);
                line.position.y = -height/2 + (i * height/numLines);
                platformGroup.add(line);
            }
        }

        platformGroup.position.set(x, y, 0);
        this.scene.add(platformGroup);

        const platform = {
            mesh: platformGroup,
            bounds: {
                left: x - width / 2,
                right: x + width / 2,
                top: y + height / 2,
                bottom: y - height / 2
            },
            type: type
        };

        this.platforms.push(platform);
        return platform;
    }

    /**
     * Check and resolve collisions with platforms
     * @param {Player} player - Player instance
     */
    checkCollisions(player) {
        const playerBounds = player.getBounds();
        const playerVelocity = player.velocity;

        for (const platform of this.platforms) {
            if (checkAABBCollision(playerBounds, platform.bounds)) {
                // Determine collision direction based on velocity and overlap
                const overlapLeft = playerBounds.right - platform.bounds.left;
                const overlapRight = platform.bounds.right - playerBounds.left;
                const overlapTop = playerBounds.top - platform.bounds.bottom;
                const overlapBottom = platform.bounds.top - playerBounds.bottom;

                // Find smallest overlap to determine collision direction
                const minOverlap = Math.min(overlapLeft, overlapRight, overlapTop, overlapBottom);

                // Resolve based on smallest overlap (most likely collision side)
                if (minOverlap === overlapBottom && playerVelocity.y < 0) {
                    // Player landed on top of platform (coming from above)
                    resolveCollisionY(player.position, platform.bounds, playerVelocity);
                    player.velocity.y = 0;
                    player.isGrounded = true;
                    player.mesh.position.y = player.position.y;
                } else if (minOverlap === overlapTop && playerVelocity.y > 0) {
                    // Player hit bottom of platform (jumping into it)
                    resolveCollisionY(player.position, platform.bounds, playerVelocity);
                    player.velocity.y = 0;
                    player.mesh.position.y = player.position.y;
                } else if (minOverlap === overlapLeft || minOverlap === overlapRight) {
                    // Player hit side of platform
                    resolveCollisionX(player.position, platform.bounds, playerVelocity);
                    player.velocity.x = 0;
                    player.mesh.position.x = player.position.x;
                }
            }
        }
    }

    /**
     * Add an enemy to the level
     * @param {EnemyBase} enemy - Enemy instance
     */
    addEnemy(enemy) {
        this.enemies.push(enemy);
    }

    /**
     * Update all enemies
     * @param {number} deltaTime - Time since last frame
     */
    updateEnemies(deltaTime) {
        for (const enemy of this.enemies) {
            if (enemy.isAlive) {
                enemy.update(deltaTime, this);
            }
        }
    }

    /**
     * Create a test level with floating platforms
     */
    createTestLevel() {
        // Main ground platform (ground type with grass)
        this.addPlatform(0, -3, 100, 1, 'ground');

        // Floating grass platforms (thin)
        this.addPlatform(5, 0, 3, 0.5, 'grass');
        this.addPlatform(10, 2, 3, 0.5, 'grass');
        this.addPlatform(-5, 1, 4, 0.5, 'grass');

        // Stone platforms (taller, for walls/obstacles)
        this.addPlatform(15, -1, 2, 3, 'stone');    // Tall stone wall on right
        this.addPlatform(-10, 0, 2, 4, 'stone');    // Very tall stone wall on left
        this.addPlatform(20, -2, 1.5, 2, 'stone');  // Medium stone platform

        // More variety
        this.addPlatform(-15, 2, 5, 0.5, 'grass');   // Far left floating
        this.addPlatform(25, 1, 3, 0.5, 'stone');    // Far right stone
        this.addPlatform(0, 4, 4, 0.5, 'grass');     // High center platform
    }
}
